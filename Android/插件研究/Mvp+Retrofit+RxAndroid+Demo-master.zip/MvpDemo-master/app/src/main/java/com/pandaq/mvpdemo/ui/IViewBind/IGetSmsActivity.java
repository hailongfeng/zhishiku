package com.pandaq.mvpdemo.ui.IViewBind;

/**
 * Created by PandaQ on 2016/12/13.
 * email : 767807368@qq.com
 */

public interface IGetSmsActivity {

    String getAddress();

    String getBody();
}
