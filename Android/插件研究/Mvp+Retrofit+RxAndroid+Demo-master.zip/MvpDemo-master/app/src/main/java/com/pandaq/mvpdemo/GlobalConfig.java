package com.pandaq.mvpdemo;

/**
 * Created by PandaQ on 2016/10/19.
 * email : 767807368@qq.com
 */

public class GlobalConfig {
    public static final boolean isDebug = true; //标示是否是 debug 版本
    public static final String baseUrl = "http://news-at.zhihu.com/api/4/";
    public static final String baseTestUrl = "https://kyfw.12306.cn/otn/index/init/";
}
