package com.pandaq.mvpdemo.enums;

/**
 * Created by PandaQ on 2016/11/20.
 * email : 767807368@qq.com
 */

public enum ClientType {
    TYPE_HTTPSUTILS,
    TYPE_OKHTTPCLIENT
}
