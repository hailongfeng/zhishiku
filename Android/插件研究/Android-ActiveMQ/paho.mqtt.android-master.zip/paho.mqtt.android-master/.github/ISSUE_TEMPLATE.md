Please fill out the form below before submitting, thank you!

- [ ] Bug exists Release Version 1.1.1 (Java Repository Master Branch)
- [ ] Bug exists in Snapshot Version 1.1.2-SNAPSHOT (Android Service Repository Master Branch)
- [ ] Bug is just in the Sample Application.

__Android API Version Bug Seen on:__

__Android Version Bug Seen on:__


Please also check that if you have found the bug in the Release version (1.1.1) that you check that it also exists in the Snapshot (1.1.2-SNAPSHOT) before raising a bug.


## Description of Bug:
E.g. Steps to re-create, how often does this happen etc..

## Console Log output (if available):
