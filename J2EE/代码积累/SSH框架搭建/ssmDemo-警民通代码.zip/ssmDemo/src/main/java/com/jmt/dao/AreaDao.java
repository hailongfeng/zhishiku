package com.jmt.dao;

public class AreaDao {

}
