package com.jmt.pojo;
/**
 * roleOffice的扩展类
 * @author T430
 *
 */
public class RoleOffice extends Role {

}
